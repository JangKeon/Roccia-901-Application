// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'accountModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AccountModel _$AccountModelFromJson(Map<String, dynamic> json) {
  return AccountModel(
    uid: json['uid'] as String,
    name: json['name'] as String,
    email: json['email'] as String,
    place: json['place'] as int,
    isAdmin: json['isAdmin'] as bool,
    isOB: json['isOB'] as bool,
    isPermit: json['isPermit'] as bool,
    level: json['level'] as int,
  );
}

Map<String, dynamic> _$AccountModelToJson(AccountModel instance) =>
    <String, dynamic>{
      'uid': instance.uid,
      'name': instance.name,
      'email': instance.email,
      'place': instance.place,
      'isAdmin': instance.isAdmin,
      'isOB': instance.isOB,
      'isPermit': instance.isPermit,
      'level': instance.level,
    };

import 'package:json_annotation/json_annotation.dart';

part 'accountModel.g.dart';

@JsonSerializable(nullable: true)
class AccountModel {
  String uid;
  String name;
  String email;
  int place;
  bool isAdmin;
  bool isOB;
  bool isPermit;
  int level;
  AccountModel({this.uid, this.name, this.email, this.place, this.isAdmin, this.isOB, this.isPermit, this.level});
  factory AccountModel.fromJson(Map<String, dynamic> json) => _$AccountModelFromJson(json);
  Map<String, dynamic> toJson() => _$AccountModelToJson(this);

  @override
  bool operator ==(Object other) => other is AccountModel && uid == other.uid;
  @override
  int get hashCode => uid.hashCode;

  @override
  String toString() {
    return toJson().toString();
  }
}

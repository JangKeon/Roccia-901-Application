import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:roccia/controller/account_controller.dart';
import 'package:roccia/model/accountModel.dart';

final FirebaseFirestore dbReference = FirebaseFirestore.instance;

class AdminPage extends StatefulWidget {
  @override
  _AdminPageState createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  final FirebaseFirestore dbReference = FirebaseFirestore.instance;

  AccountController _accountController = Get.find<AccountController>();

  List<AccountModel> accountList = [];

  List<String> placeList = ['양재', '홍대', '서울대', '마곡'];

  List<String> ColorNameList = ['흰색', '노랑', '주황', '초록', '파랑', '빨강', '보라', '회색', '갈색', '검정'];

  @override
  Widget build(BuildContext context) {
    return !_accountController.account.isAdmin
        ? Center(
            child: Text('당신은 관리자가 아닙니다 삐빅'),
          )
        : FutureBuilder(
            future: dbReference.collection('users').get(),
            builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.hasData && snapshot.data != null) {
                List<QueryDocumentSnapshot> data = snapshot.data.docs;
                accountList = [];
                data.forEach((element) {
                  Map<dynamic, dynamic> data = element.data();
                  AccountModel account = AccountModel(
                      email: data['email'],
                      name: data['name'],
                      place: data['place'],
                      isAdmin: data['isAdmin'],
                      isOB: data['isOB'],
                      isPermit: data['isPermit'],
                      level : data['level']
                  );
                  accountList.add(account);
                });
                return Scaffold(
                  appBar: AppBar(
                    title: Text(
                      '관리자 페이지',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  body: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      firstRowItem(),
                      Expanded(
                        child: ListView.builder(
                          itemCount: accountList.length,
                          itemBuilder: (BuildContext context, int index) {
                            AccountModel account = accountList[index];
                            return rowItem(account.email, account.name, account.place, account.isAdmin, account.isPermit, account.level);
                          },
                        ),
                      ),
                    ],
                  ),
                );
              } else
                return Center(child: CircularProgressIndicator());
            });
  }

  firstRowItem() {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(child: Center(child: Text('이름'))),
          Expanded(child: Center(child: Text('장소'))),
          Expanded(child: Center(child: Text('일반/관리자'))),
          Expanded(child: Center(child: Text('승인/레벨')))
        ],
      ),
    );
  }

  rowItem(String email, String name, int place, bool isAdmin, bool isPermit, int level) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: Row(
        children: [
          Expanded(child: Center(child: Text(name))),
          Expanded(child: Center(child: Text(placeList[place]))),
          Expanded(
            child: Center(
                child: Checkbox(
              value: isAdmin,
              onChanged: (bool value) {
                onclickCheckboxAdmin(email, value);
              },
            )),
          ),
          isPermit
              ? Expanded(
                  child: Center(child: Text(ColorNameList[level??0])),
                )
              : Expanded(
                  child: Center(
                      child: Checkbox(
                    value: isPermit,
                    onChanged: (bool value) {
                      onclickCheckboxPermit(email);
                    },
                  )),
                )
        ],
      ),
    );
  }

  onclickCheckboxPermit(String email) {
    dbReference.collection("users").doc(email).update({"isPermit": true});
    setState(() {});
  }

  onclickCheckboxAdmin(String email, bool value) {
    dbReference.collection("users").doc(email).update({"isAdmin": value});
    setState(() {});
  }
}
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:roccia/pages/adminPage.dart';
import 'package:roccia/pages/OBPage.dart';
import 'package:roccia/pages/myPage.dart';

class LobbyPage extends StatefulWidget {
  @override
  _LobbyPageState createState() => _LobbyPageState();
}

class _LobbyPageState extends State<LobbyPage> with SingleTickerProviderStateMixin {
  TabController tabController;

  @override
  void initState() {
    tabController = TabController(length: 4, vsync: this);
    tabController.addListener(() {
      setState(() {});
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print('전체 rebuild');
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: TabBarView(
              controller: tabController,
              children: <Widget>[
                MyPage(),
                Center(
                  child: Text('attendance page'),
                ),
                OBPage(),
                AdminPage(),
              ],
            ),
          ),
          Container(
            height: 50,
            child: Row(
              children: [
                buildTabItem('마이페이지', 0),
                buildTabItem('출석', 1),
                buildTabItem('OB', 2),
                buildTabItem('관리자', 3),
              ],
            ),
          )
        ],
      ),
    );
  }

  GestureDetector buildTabItem(String text, int index) {
    bool active = tabController.index == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          tabController.index = index;
        });
      },
      child: Container(
          width: Get.width / 4,
          child: Center(
              child: Text(
            text,
            style: TextStyle(color: active ? Colors.black : Colors.grey),
          ))),
    );
  }
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:roccia/controller/account_controller.dart';

class MyPage extends StatefulWidget {
  @override
  _MyPageState createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  final FirebaseFirestore dbReference = FirebaseFirestore.instance;
  final AccountController a = Get.find();

  List<String> ColorNameList = ['흰색', '노랑', '주황', '초록', '파랑', '빨강', '보라', '회색', '갈색', '검정'];
  List<int> ColorList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

  List<String> placeNameList = ['양재', '홍대', '서울대', '마곡'];
  List<int> placeList = [0, 1, 2, 3];

  @override
  void initState() {
    a.addListener(() {setState(() {});});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            '마이페이지',
            style: TextStyle(color: Colors.white),
          ),
          actions: [
            FlatButton(
              onPressed: () {
                FirebaseAuth.instance.signOut();
              },
              child: Text('Logout'),
            ),
          ],
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            _logoImage(),
            Text(
              '이름 : ' + a.account.name,
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(
              height: 10,
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center, children: [
              Text('지점 : ', style: TextStyle(fontSize: 24)),
              DropdownButton<int>(
                value: a.account.place,
                icon: Icon(Icons.arrow_downward),
                iconSize: 24,
                elevation: 16,
                style: TextStyle(color: Colors.deepPurple, fontSize: 24),
                underline: Container(
                  height: 2,
                  color: Colors.deepPurpleAccent,
                ),
                onChanged: (int newValue) {
                  setState(() {
                    a.account.place = newValue;
                    dbReference.collection("users").doc(FirebaseAuth.instance.currentUser.email).update({'place': newValue});
                  });
                },
                items: placeList.map<DropdownMenuItem<int>>((int value) {
                  return DropdownMenuItem<int>(
                    value: value,
                    child: Text(placeNameList[value]),
                  );
                }).toList(),
              )
            ]),
            SizedBox(
              height: 10,
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center, children: [
              Text('레벨 : ', style: TextStyle(fontSize: 24)),
              DropdownButton<int>(
                value: a.account.level,
                icon: Icon(Icons.arrow_downward),
                iconSize: 24,
                elevation: 16,
                style: TextStyle(color: Colors.deepPurple, fontSize: 24),
                underline: Container(
                  height: 2,
                  color: Colors.deepPurpleAccent,
                ),
                onChanged: (int newValue) {
                  setState(() {
                    a.account.level = newValue;
                    dbReference.collection("users").doc(FirebaseAuth.instance.currentUser.email).update({'level': newValue});
                  });
                },
                items: ColorList.map<DropdownMenuItem<int>>((int value) {
                  return DropdownMenuItem<int>(
                    value: value,
                    child: Text(ColorNameList[value]),
                  );
                }).toList(),
              )
            ]),
            SizedBox(
              height: 20,
            ),
            FlatButton(
              child: Text('회원 탈퇴', style: TextStyle(fontSize: 20)),
              onPressed: () => Get.defaultDialog(
                  title: '회원 탈퇴', middleText: '정말 탈퇴하시겠습니까?', cancel: GestureDetector(onTap: () {
                    deleteAccount();
                    Get.back();
                  }, child: Text('예'))),
              color: Colors.black12,
              textColor: Colors.redAccent,
            )
          ], //children
        ));
  }

  Widget _logoImage() {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.only(
          left: 15,
          right: 15,
        ),
        child: FittedBox(
          fit: BoxFit.contain,
          child: CircleAvatar(
            backgroundColor: Colors.white,
            child: Image.asset('assets/roccia_logo.png'),
          ),
        ),
      ),
    );
  }

  deleteAccount() {
    dbReference.collection("users").doc(FirebaseAuth.instance.currentUser.email).delete();
    FirebaseAuth.instance.currentUser.delete();
//        FirebaseAuth.instance.();
    FirebaseAuth.instance.signOut();
  }
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:roccia/controller/account_controller.dart';
import 'package:roccia/controller/ob_checkBox_controller.dart';

class OBPage extends StatefulWidget {
  @override
  _OBPageState createState() => _OBPageState();
}

class _OBPageState extends State<OBPage> {
  int selectedIndex;
  List ltDateWeekList = [];
  List ltDateList = [];
  List gteDateWeekList = [];
  List gteDateList = [];
  Map<dynamic, dynamic> dateMap = {};
  List dateMapList = [];

  final FirebaseFirestore dbReference = FirebaseFirestore.instance;

  final AccountController a = Get.find();
  final OBCheckBoxController o = Get.put(OBCheckBoxController());

  @override
  void initState() {
    var d = DateTime.now().subtract(Duration(days: 1));
    var current = d.weekday;
    for (var i = 1; i < current; i++) {
      ltDateWeekList.add(i);
    }
    if (current == 0) {
      gteDateWeekList.add(0);
      for (var i = 1; i < 7; i++) {
        gteDateWeekList.add(i);
      }
    } else {
      for (var i = current; i < 7; i++) {
        gteDateWeekList.add(i);
      }
      gteDateWeekList.add(0);
    }

    ltDateList = ltDateWeekList
        .map((e) => dateMap[e] = {
              'date': DateFormat('yyyy-MM-dd').format(d.subtract(Duration(days: current - e)).add(Duration(days: 7))),
              'isNext': true
            })
        .toList();
    gteDateList = gteDateWeekList
        .map((e) =>
            dateMap[e] = {'date': DateFormat('yyyy-MM-dd').format(d.add(Duration(days: gteDateWeekList.indexOf(e)))), 'isNext': false})
        .toList();
    print('dateMap $dateMap');
    dateMapList = [dateMap[1], dateMap[2], dateMap[3], dateMap[6]];
    print(dateMapList);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            gteDateList[0]['date'],
            style: TextStyle(color: Colors.white),
          ),
          actions: [
            FlatButton(
              onPressed: () {
                FirebaseAuth.instance.signOut();
              },
              child: Text('Logout'),
            ),
          ],
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            rowItem('지점', {'date': '날짜'}, isText: true),
            rowItem('양재', dateMap[1], index: 0),
            rowItem('홍대', dateMap[2], index: 1),
            rowItem('서울대', dateMap[3], index: 2),
            rowItem('마곡', dateMap[6], index: 3),
          ],
        ));
  }

  rowItem(String place, Map dateInfo, {int index, bool isText = false}) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(child: Center(child: Text(place))),
          Expanded(child: Center(child: Text(dateInfo['date']))),
          isText
              ? Expanded(
                  flex: 2,
                  child: Row(
                    children: [Expanded(child: Center(child: Text('예약 현황'))), Expanded(child: Center(child: Text('예약 버튼')))],
                  ),
                )
              : StreamBuilder<DocumentSnapshot>(
                  stream: FirebaseFirestore.instance.collection('ob_reserves').doc(dateInfo['date']).snapshots(),
                  builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                    if (snapshot.hasData) if (snapshot.data.data() != null) {
                      List uidList = snapshot.data.data().keys.toList();
                      if (uidList.contains(a.account.uid)) {
                        dateInfo['isNext'] ? o.updateNextWeekIndex(index) : o.updateThisWeekIndex(index);
                      }
                      print('thisWeekIndex : ${o.thisWeekIndex}, nextWeekIndex : ${o.nextWeekIndex}');
                      return Expanded(
                        flex: 2,
                        child: Row(
                          children: [
                            Expanded(
                                child: GestureDetector(
                                    onTap: () => onTapReservationStatus(dateInfo['date']),
                                    child: Center(child: Text('${snapshot.data.data().keys.length} / 3')))),
                            Expanded(
                              child: Center(
                                child: Checkbox(
                                  value: uidList.contains(a.account.uid),
                                  onChanged: (bool value) {
                                    onclickCheckbox(index, value, dateInfo,
                                        isExist: true, isDelete: uidList.contains(a.account.uid), current_ob_numbers: uidList.length);
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    } else
                      return Expanded(
                        flex: 2,
                        child: Row(
                          children: [
                            Expanded(child: Center(child: Text('0 / 3'))),
                            Expanded(
                              child: Center(
                                child: Checkbox(
                                  value: false,
                                  onChanged: (bool value) {
                                    onclickCheckbox(index, value, dateInfo);
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    else
                      return Text('준비중');
                  }),
        ],
      ),
    );
  }

  onTapReservationStatus(String date) async {
    var result = await dbReference.collection('ob_reserves').doc(date).get();
    Get.defaultDialog(title: '예약 현황', content: Column(children: result.data().values.map((e) => Text(e+'\n')).toList()));
  }

  onclickCheckbox(int index, bool value, Map<dynamic, dynamic> dateInfo, {isExist: false, isDelete: false, int current_ob_numbers}) {
    final isToday = o.thisWeekIndex.value != 5 ? gteDateList[0]['date'] == dateMapList[o.thisWeekIndex.value]['date'] : false;
    if (a.account.isOB) {
      if (isExist) {
        // document 가 존재할 떄
        if (isDelete) {
          // 예약되어 있는 날짜 눌렀을 때 (삭제)
          if (!isToday) {
            // 오늘 예약이 존재 x
            deleteDocField(dateInfo['date']); // 예약 삭제

            // controller index 5 로 초기화
            // boolean 'A ? B : C' A가 true 면 b가 실행, 아니면(false) c가 실행
            dateInfo['isNext'] ? o.updateNextWeekIndex(5) : o.updateThisWeekIndex(5);
          } else {
            // 오늘 예약이 존재
            if (dateInfo['isNext']) {
              deleteDocField(dateInfo['date']);
              o.updateNextWeekIndex(5);
            } else
              Get.defaultDialog(title: '알림', onConfirm: () => Get.back(), middleText: '당일 취소가 불가합니다.', buttonColor: Colors.white);
          }
        } else {
          // 예약하려고 버튼 눌렀을 때
          if ((current_ob_numbers >= 3)) // 풀방일 때
            Get.defaultDialog(title: '알림', onConfirm: () => Get.back(), middleText: '예약이 다 찼습니다!', buttonColor: Colors.white);
          else {
            if (dateInfo['isNext']) {
              // 다음주 예약
              if (o.nextWeekIndex.value != index && o.nextWeekIndex.value != 5) {
                // 기존 예약 있을 때
                deleteDocField(dateMapList[o.nextWeekIndex.value]['date']); // 기존 예약 삭제
                updateDocField(dateInfo['date']); // 예약
              } else
                updateDocField(dateInfo['date']); // 예약
            } else {
              if (!isToday) {
                if (o.thisWeekIndex.value != index && o.thisWeekIndex.value != 5) {
                  deleteDocField(dateMapList[o.thisWeekIndex.value]['date']); // 기존 예약 삭제
                  updateDocField(dateInfo['date']); // 예약
                } else
                  updateDocField(dateInfo['date']); // 예약
              } else
                Get.defaultDialog(title: '알림', onConfirm: () => Get.back(), middleText: '이번주는 예약이 불가합니다.', buttonColor: Colors.white);
            }
          }
        }
      } else {
        // document 가 존재 x
        if (dateInfo['isNext']) {
          // 다음주 예약
          if (o.nextWeekIndex.value == 5)
            // 다음주 예약이 존재 x
            setDocField(dateInfo['date']); // 예약
          else
            // 다음주 예약이 존재
            Get.defaultDialog(title: '알림', onConfirm: () => Get.back(), middleText: '1주일에 1회 예약 가능합니다.', buttonColor: Colors.white);
        } else {
          // 이번주 예약
          if (isToday)
            // 오늘 예약이 존재
            Get.defaultDialog(title: '알림', onConfirm: () => Get.back(), middleText: '당일 취소가 불가합니다.', buttonColor: Colors.white);
          else {
            // 오늘 예약이 존재 x
            if (o.thisWeekIndex.value == 5)
              // 이번주 예약 존재 x
              setDocField(dateInfo['date']); // 예약
            else
              // 이번주 예약 존재
              Get.defaultDialog(title: '알림', onConfirm: () => Get.back(), middleText: '1주일에 1회 예약 가능합니다.', buttonColor: Colors.white);
          }
        }
      }
    }
  }

  deleteDocField(date) => dbReference.collection("ob_reserves").doc(date).update({a.account.uid: FieldValue.delete()}); // field 값 삭제

  updateDocField(date) => dbReference.collection("ob_reserves").doc(date).update({a.account.uid: a.account.name}); // field 값 수정

  setDocField(date) => dbReference.collection("ob_reserves").doc(date).set({a.account.uid: a.account.name}); // doc 생성 && field 값 삭제
}

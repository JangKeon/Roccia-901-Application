import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:roccia/pages/login/forget_pw.dart';

class StartPage extends StatefulWidget {
  @override
  _StartPageState createState() => _StartPageState();
}

class _StartPageState extends State<StartPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _emailController = TextEditingController();

  final TextEditingController _passwordController = TextEditingController();

  final TextEditingController _nameController = TextEditingController();

  final FirebaseFirestore dbReference = FirebaseFirestore.instance;

  List<String> placeNameList = ['양재', '홍대', '서울대', '마곡'];
  List<int> placeList = [0, 1, 2, 3];
  int _place = 0;
  bool _isJoin = true;

  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          Container(
            color: Colors.white,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              _logoImage(isJoin: _isJoin),
              Stack(
                children: <Widget>[
                  _inputForm(size),
                  _authButton(size),
                ],
              ),
              Container(
                height: size.height * 0.04,
              ),
              GestureDetector(
                  onTap: () {
                    setState(() {
                      _isJoin = !_isJoin;
                    });
                  },
                  child: Text(
                    _isJoin ? "계정이 없으신가요? 회원가입하러 가기" : "이미 회원이신가요? 로그인하러 가기",
                    style: TextStyle(color: _isJoin ? Colors.indigo : Colors.redAccent),
                  )),
              Container(
                height: size.height * 0.05,
              ),
            ],
          )
        ],
      ),
    );
  }

  void createUser(String uid) {
    dbReference.collection("users").doc(_emailController.text).set({
      'email': _emailController.text,
      'uid' : uid,
      'name': _nameController.text,
      'place': _place,
      'isPermit': false,
      'isOB': false,
      'isAdmin': false,
      'level' : 0
    });
  }

  void _register(BuildContext context) async {
    UserCredential result;
    try{
      result = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: _emailController.text, password: _passwordController.text);
    } catch (e) {
      if (e.toString() == '[firebase_auth/email-already-in-use] The email address is already in use by another account.')
        Get.defaultDialog(title: '회원가입 오류', middleText : '이미 존재하는 이메일입니다.', cancel: GestureDetector(onTap: () => Get.back(), child: Text('확인')));
      else Get.defaultDialog(title: '회원가입 오류', middleText : '죄송합니다. 오류가 발생하였습니다.', cancel: GestureDetector(onTap: () => Get.back(), child: Text('확인')));
    }
    final User user = result.user;

    if (user == null) {
      final snackBar = SnackBar(
        content: Text('다시 시도해주세요'),
      );
      Scaffold.of(context).showSnackBar(snackBar);
    } else
      createUser(user.uid);
  }

  void _login(BuildContext context) async {
    final UserCredential result =
        await FirebaseAuth.instance.signInWithEmailAndPassword(email: _emailController.text, password: _passwordController.text);
    final User user = result.user;

    if (user == null) {
      final snackBar = SnackBar(
        content: Text('다시 시도해주세요'),
      );
      Scaffold.of(context).showSnackBar(snackBar);
    }
  }

  Widget _logoImage({bool isJoin}) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.only(
          top: 40,
          left: 15,
          right: 15,
        ),
        child: FittedBox(
          fit: BoxFit.contain,
          child: CircleAvatar(
            backgroundColor: isJoin ? Colors.white : Colors.redAccent,
            child: Image.asset('assets/roccia_logo.png'),
          ),
        ),
      ),
    );
  }

  Widget _inputForm(Size size) {
    return Padding(
      padding: EdgeInsets.only(left: 20, right: 20, bottom: 20),
      child: Card(
        elevation: 6,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 13, right: 13, top: 14, bottom: 30),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                TextFormField(
                  controller: _emailController,
                  decoration: InputDecoration(icon: Icon(Icons.account_circle), labelText: '이메일'),
                  validator: (String value) {
                    if (value.isEmpty) {
                      return '알맞은 이메일을 입력해주세요.';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  obscureText: true,
                  controller: _passwordController,
                  decoration: InputDecoration(icon: Icon(Icons.vpn_key), labelText: '비밀번호'),
                  validator: (String value) {
                    if (value.isEmpty) {
                      return '알맞은 비밀번호를 입력해주세요.';
                    }
                    return null;
                  },
                ),
                _isJoin
                    ? Container()
                    : Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _nameController,
                              decoration: InputDecoration(icon: Icon(Icons.title), labelText: '이름'),
                              validator: (String value) {
                                if (value.isEmpty) {
                                  return '이름을 입력해주세요.';
                                }
                                return null;
                              },
                            ),
                          ),
                          DropdownButton<int>(
                            value: _place,
                            icon: Icon(Icons.arrow_downward),
                            iconSize: 24,
                            elevation: 16,
                            style: TextStyle(color: Colors.deepPurple),
                            underline: Container(
                              height: 2,
                              color: Colors.deepPurpleAccent,
                            ),
                            onChanged: (int newValue) {
                              setState(() {
                                _place = newValue;
                              });
                            },
                            items: placeList.map<DropdownMenuItem<int>>((int value) {
                              return DropdownMenuItem<int>(
                                value: value,
                                child: Text(placeNameList[value]),
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                Container(
                  height: 10,
                ),
                Opacity(
                    opacity: _isJoin ? 1 : 0,
                    child: GestureDetector(
                        onTap: _isJoin
                            ? () {
                                goToForgetPW(context);
                              }
                            : null,
                        child: Text(
                          '비밀번호를 잊으셨나요?',
                          style: TextStyle(color: Colors.grey),
                        ))),
              ],
            ),
          ),
        ),
      ),
    );
  }

  goToForgetPW(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ForgetPW()),
    );
  }

  Widget _authButton(Size size) {
    return Positioned(
      left: size.width * 0.2,
      right: size.width * 0.2,
      bottom: 0,
      child: SizedBox(
        height: 40,
        child: RaisedButton(
          child: Text(
            _isJoin ? '로그인' : "회원가입",
            style: TextStyle(
              fontSize: 20,
              color: Colors.white,
            ),
          ),
          color: _isJoin ? Colors.indigoAccent : Colors.redAccent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          onPressed: () {
            if (_formKey.currentState.validate()) {
              _isJoin ? _login(context) : _register(context);
            }
          },
        ),
      ),
    );
  }
}

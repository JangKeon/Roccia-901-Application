import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:roccia/controller/account_controller.dart';
import 'package:roccia/model/accountModel.dart';
import 'package:roccia/pages/lobbyPage.dart';

class WaitingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: RefreshIndicator(
          onRefresh: () => _onRefresh(),
          child: ListView(
            children: [
              SizedBox(height: Get.height * 0.4),
              Column(
                children: [
                  Text('승인을 요청중입니다.'),
                  FlatButton(
                    onPressed: () {
                      FirebaseAuth.instance.signOut();
                    },
                    child: Text('다른 계정으로 로그인'),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Future _onRefresh() async {
    var userDoc = await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser.email).get();
    Map<dynamic, dynamic> data = userDoc.data();
    print(data);
    if (data['isPermit']) {
      AccountModel account = AccountModel.fromJson(data);
      print('account : $account');
      AccountController _controller = Get.put(AccountController(account: account));
      Get.offAll(LobbyPage());
    }
  }
}

import 'package:get/get.dart';
import 'package:roccia/model/accountModel.dart';

class AccountController extends GetxController {
  AccountModel account;
  AccountController({this.account});
}
import 'package:get/get.dart';

class OBCheckBoxController extends GetxController {
  var thisWeekIndex = 5.obs; // 예약된 버튼의 index (5 면 예약 없는거)
  var nextWeekIndex = 5.obs;

  void updateThisWeekIndex(newIndex) => thisWeekIndex.value = newIndex; // 예약된 버튼 index 업데이트

  void updateNextWeekIndex(newIndex) => nextWeekIndex.value = newIndex;
}
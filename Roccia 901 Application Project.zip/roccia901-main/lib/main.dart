import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:roccia/controller/account_controller.dart';
import 'package:roccia/model/accountModel.dart';
import 'package:roccia/pages/OBPage.dart';
import 'package:roccia/pages/lobbyPage.dart';
import 'package:roccia/pages/login/startPage.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:roccia/pages/login/waiting_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Roccia901',
      theme: ThemeData(
          primarySwatch: Colors.grey,
          visualDensity: VisualDensity.adaptivePlatformDensity,
          textTheme: TextTheme(body1: TextStyle(fontSize: 16.0))),
      home: Splash(),
      routes: {
        '/first': (context) => OBPage(),
      },
    );
  }
}

class Splash extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.data == null) {
            return StartPage();
          } else {
            return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance
                    .collection('users')
                    .doc(snapshot.data.email).get(),
                builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                  if (snapshot.hasData) {
                    Map<dynamic, dynamic> data = snapshot.data.data();
                    data['uid'] = FirebaseAuth.instance.currentUser.uid;
                    if(data['isPermit']) {
                      AccountModel account = AccountModel.fromJson(data);
                      print('account : $account');
                      return GetBuilder<AccountController>(
                        init: AccountController(account : account),
                          builder: (_) => LobbyPage());
                    }
                    else {
                      return WaitingPage();
                    }
//                Account account = Account.fromJson(snapshot.data);

                  } else
                    return Container();
                });
          }
        });
  }
}